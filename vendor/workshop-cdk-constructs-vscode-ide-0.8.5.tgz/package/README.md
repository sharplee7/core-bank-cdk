# VSCode Constructs

This package provides constructs related to building a VSCode IDE running on EC2 using the `code-server` open source project. This can be used as an alternative to Cloud9 for an IDE that workshop participants can use.

Features:

- Run code-server distribution of VSCode IDE on any EC2 instance type of your choosing
- Leverages Amazon Linux 2023 for our latest supported variant of Amazon Linux
- Easily configure aspects such as disk space, IAM permissions
- Simple parameter to provide a custom bootstrap script to install additional software or components
- Secure: Randomly generated password, encryption-in-transit with HTTP via CloudFront, locked down access with security group prefix lists
- Home directory structure mirrors Cloud9 for ease of migration (`/home/ec2-user/environment`)
- Regular updates with the upstream code-server project

[[_TOC_]]

## Installation

You can add this package to your project like so:

```bash
npm i --save @workshop-cdk-constructs/vscode-ide
```

## Constructs

These are the constructs provided by this package.

### VSCodeIde

This construct creates a VSCode IDE running on EC2.

The following code snippet provides as example which:

- Configures the root volume size to 32GB
- Outputs the password for the IDE

```ts
import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import { VSCodeIde } from "@workshop-cdk-constructs/vscode-ide";

export class VSCodeExampleStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const ide = new VSCodeIde(this, "Ide", {
      diskSize: 32,
    });
  }
}
```

#### Configuration properties

These configuration options are available:

| Name                      | Type                   | Default                                                              | Description                                                                                              |
| ------------------------- | ---------------------- | -------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------- |
| `boostrapScript`          | `string`               | `""`                                                                 | A shell script that will be run on the EC2 instance as part of the bootstrap procedure.                  |
| `terminalOnStartup`       | `boolean`              | `false`                                                              | Automatically launch the terminal when the IDE starts up.                                                |
| `extensions`              | `string[]`             | `[]`                                                                 | A list of VSCode extension names to install as part of the bootstrap process.                            |
| `environmentContentsZip`  | `string`               | `""`                                                                 | URL to a ZIP archive that will be extracted to `/home/ec2-user/environment`, can be either HTTP(S) or S3 |
| `splashUrl`               | `string`               | `""`                                                                 | A URL that will be opened when the IDE launches                                                          |
| `vpc`                     | `ec2.Vpc`              | `undefined`                                                          | An existing VPC which the EC2 instance will be run in. If left undefined a minimal VPC will be created.  |
| `instanceType`            | `ec2.InstanceType`     | `ec2.InstanceType.of(ec2.InstanceClass.T3, ec2.InstanceSize.MEDIUM)` | The EC2 instance type to use.                                                                            |
| `machineImage`            | `ec2.MachineImage`     | `ec2.MachineImage.latestAmazonLinux2023()`                           | The AMI the EC2 instance will use.                                                                       |
| `diskSize`                | `number`               | `30`                                                                 | The size of the root EBS volume.                                                                         |
| `codeServerVersion`       | `string`               | `4.91.1`                                                             | The version of `code-server` that will be used.                                                          |
| `additionalIamPolicies`   | `iam.IManagedPolicy[]` | `[]`                                                                 | Array of IAM policies that will be added to the IAM role used by the EC2 instance.                       |
| `bootstrapTimeoutMinutes` | `number`               | `15`                                                                 | How long until the bootstrap script is considered to have timed out.                                     |
| `enableGitea`             | `boolean`              | `false`                                                              | Enables a Gitea server hosted on the IDE instance that provides a Git repository and other features.     |

#### Public properties

These public properties are available:

| Property       | Type           | Description                                                                                         |
| -------------- | -------------- | --------------------------------------------------------------------------------------------------- |
| `ec2Instance`  | `ec2.Instance` | The EC2 instance provisioned for the VS Code IDE.                                                   |
| `idePassword`  | `string`       | The password for the VS Code IDE.                                                                   |
| `accessUrl`    | `string`       | The URL to access the VS Code IDE.                                                                  |
| `ideRole`      | `iam.Role`     | The IAM role associated with the VS Code IDE instance.                                              |
| `bootstrapped` | `IDependable`  | A dependency that can be used to ensure the IDE is fully bootstrapped before executing other tasks. |

#### Writing the bootstrap script

The bootstrap script is run as `root` so you must be careful with regards to file ownership etc. when creating things like files. To execute a command as `ec2-user`, which will be used by the end-user, do this:

```bash
sudo -u ec2-user bash -c 'touch ~/environment/example.txt'
```

The following environment variables are already available when writing your bootstrap script:

| Variable                 | Description                                        |
| ------------------------ | -------------------------------------------------- |
| `INSTANCE_IAM_ROLE_NAME` | The name of the IAM role used by the IDE instance. |
| `INSTANCE_IAM_ROLE_ARN`  | The ARN of the IAM role used by the IDE instance.  |
| `AWS_REGION`             | The AWS region where the IDE is running.           |
| `EC2_PRIVATE_IP`         | The VPC private IP address of the IDE.             |

If other environment variables are noted and are not documented above then you cannot rely on them. In that case please raise an GitLab issue to request it be added.

#### Automatically open the terminal

Many workshops immediately instruct their participants to open the VSCode terminal, and will spend most of their time there. You can configure the construct to automatically open the terminal by setting the `terminalOnStartup` property to true. This provides a smoother experience for workshop participants and allows them to get started without additional instructions from the author.

#### Pre-populating code

The `/home/ec2-user/environment` directory is intended to be the main working directory for the user. It is common to want to add files to this directory for the user to see when they initially access the IDE. This can be done with the `environmentContentsZip` property, which access a URL to a ZIP file that will be extracted in to the directory. The URL can be either HTTP(S) or S3:

```ts
const ide = new VSCodeIde(this, "Ide", {
  //...
  environmentContentsZip: "s3://somebucket/file.zip",
});
```

#### Using the README file

If there is a file called `README.md` in the `~/environment` directory then VSCode will automatically open it in Markdown preview mode. For example this used the README file from the CDK repository:

![README tab](./docs/images/readme.png)

This can be great to provide your workshop users with any information useful to orient themselves in VSCode. You can populate this file using `environmentContentsZip` or the bootstrap script.

#### Installing VSCode extensions

VSCode extensions can be installed using the `extensions` property:

```ts
const ide = new VSCodeIde(this, "Ide", {
  //...
  extensions: ["redhat.vscode-yaml"],
});
```

To get the name of the extension you can browse the [Open VSX Registry](https://open-vsx.org/). Opening an item will show the name in the URL but you'll need to translate the `/` in to a `.`. For example the URL for the above extension is:

```text
https://open-vsx.org/extension/redhat/vscode-yaml
```

Alternatively extensions can be installed in the `bootstrapScript` or manually by the user. For example:

```bash
sudo -u ec2-user bash -c 'code-server --install-extension AmazonWebServices.aws-toolkit-vscode --force'
```

#### Using the Gitea server

Gitea can be used to provide a Git server for a workshop in case it is required. See the [dedicated documentation](./docs/gitea.md) for this feature.
